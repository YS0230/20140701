package com.example.project;

import android.widget.SlidingDrawer;

public class slidingOC {
	public slidingOC(final SlidingDrawer sd_top, final SlidingDrawer sd_right) {
		/* �]�wSlidingDrawer_Top���}������SlidingDrawer_Right */ 
		sd_top.setOnDrawerOpenListener
		(new SlidingDrawer.OnDrawerOpenListener(){ 
			@Override 
			public void onDrawerOpened(){
				if(sd_right.isOpened())
					sd_right.animateClose();
			} 
		}); 
		
		/* �]�wSlidingDrawer_Right���}������SlidingDrawer_Top */ 
		sd_right.setOnDrawerOpenListener
		(new SlidingDrawer.OnDrawerOpenListener(){ 
			@Override 
			public void onDrawerOpened(){
				if(sd_top.isOpened())
					sd_top.animateClose();
			} 
		}); 
	}
}
