package com.example.project;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.SlidingDrawer;
import android.widget.Spinner;

public class MainActivity extends Activity {
	private Spinner spnMaterial;
	private DisplayMetrics dm;
	private Bitmap bitmap;
	
	private ImageView imageView;
	
	private SlidingDrawer sd_top;
	private SlidingDrawer sd_right;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		/* ��P�}�� */
		sd_top = (SlidingDrawer) findViewById(R.id.sd_top);
		sd_right = (SlidingDrawer) findViewById(R.id.sd_right);
		new slidingOC(sd_top, sd_right);
		
		/* �U�Ԧ��M�椺�e */
		spnMaterial = (Spinner) findViewById(R.id.spnMaterial);
		new spnMaterial(this, spnMaterial);
		
		/* �즲 �Y�� */
		dm = new DisplayMetrics();
		getWindowManager().getDefaultDisplay().getMetrics(dm);
				
		imageView = (ImageView)findViewById(R.id.image_view);
		
		bitmap = BitmapFactory.decodeResource(getResources(), R.drawable.a);
		imageView.setImageBitmap(bitmap);
		new ImageViewHelper(dm,imageView,bitmap);
	}
}
