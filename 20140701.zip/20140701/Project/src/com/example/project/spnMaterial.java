package com.example.project;

import android.widget.ArrayAdapter;
import android.widget.Spinner;

public class spnMaterial {
	String[] Material = new String[] {"����", "a", "b"};
	public spnMaterial(MainActivity mainActivity, Spinner spnMaterial){
		ArrayAdapter<String> adapterMaterial = new ArrayAdapter<String>
		  (mainActivity, android.R.layout.simple_spinner_item, Material);
		adapterMaterial.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		spnMaterial.setAdapter(adapterMaterial);
	}
}
